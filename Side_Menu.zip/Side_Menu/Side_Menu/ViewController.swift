import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate, UIScrollViewDelegate {
    
    @IBOutlet weak var src: UIScrollView!
    @IBOutlet weak var pageController: UIPageControl!
    
    var yaxis = 15
    var xaxix = 14
    let MenubarItemName = ["Notice","Meeting","Invite","Events","Voting","Visitor","Expenditure"]
    var img = [#imageLiteral(resourceName: "icons8-monitor-filled-50"),#imageLiteral(resourceName: "icons8-people-51"),#imageLiteral(resourceName: "icons8-open-envelope-filled-50"),#imageLiteral(resourceName: "icons8-timetable-50"),#imageLiteral(resourceName: "icons8-elections-50"),#imageLiteral(resourceName: "icons8-waiting-room-50"),#imageLiteral(resourceName: "icons8-general-ledger-50")]
    let btn = custombutton()
    let Menubarbtn = customviewmenubar()
    let ScrBtnName = MenuBarButtonName()
    
    var Menu_VC = MenuViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        src.delegate = self as? UIScrollViewDelegate
        for i in  0..<7
        {
            
            let view2 = Menubarbtn.createview(frm: CGRect(x: xaxix, y: yaxis, width: 95, height: 110))
            
            
            
            if i == 6 {
                let round = btn.createbtn(frm: CGRect(x: 20, y: 3, width: 60, height: 60),img:img[i])
                view2.addSubview(round)
            }
            else{
                let round = btn.createbtn(frm: CGRect(x: 15, y: 3, width: 60, height: 60),img:img[i])
                view2.addSubview(round)
                
            }
            
            src.contentSize = CGSize(width: self.view.frame.size.width * 2, height: 75 )
            
            if MenubarItemName[i] == "Invite" {
                let BtnName = ScrBtnName.createname(frm: CGRect(x: 24, y: 65, width: 110, height: 20 ), name:  MenubarItemName[i])
                view2.addSubview(BtnName)
                
            }
            else if MenubarItemName[i] == "Expenditure"{
                let BtnName = ScrBtnName.createname(frm: CGRect(x: 10, y: 65, width: 110, height: 20), name:  MenubarItemName[i])
                view2.addSubview(BtnName)
                
            }
                
            else if MenubarItemName[i] == "Voting" || MenubarItemName[i] == "Visitor"{
                let BtnName = ScrBtnName.createname(frm: CGRect(x: 20, y: 65, width: 110, height: 20), name:  MenubarItemName[i])
                view2.addSubview(BtnName)
                
            }
                
            else{
                let BtnName = ScrBtnName.createname(frm: CGRect(x: 15, y: 65, width: 110, height: 20 ), name: MenubarItemName[i])
                view2.addSubview(BtnName)
            }
            
            
            
            
            self.src.addSubview(view2)
            xaxix = xaxix+100
            
        }
        
        
        

        Menu_VC = self.storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        let left_Swipe = UISwipeGestureRecognizer(target: self, action: #selector(self.SwipeGesture))
        left_Swipe.direction = .left
        
        let Right_Swipe = UISwipeGestureRecognizer(target: self, action: #selector(self.SwipeGesture))
        Right_Swipe.direction = UISwipeGestureRecognizerDirection.right
        
        self.view.addGestureRecognizer(left_Swipe)
        self.view.addGestureRecognizer(Right_Swipe)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let page = src.contentOffset.x/src.frame.width
        pageController.currentPage = Int(page)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.Menu_VC.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width:  UIScreen.main.bounds.size.width, height:  UIScreen.main.bounds.size.height)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        Hide_Menu()
    }
    func SwipeGesture(sender : UISwipeGestureRecognizer)  {
        
        if sender.direction == .left {
            Hide_Menu()
        }
        else if sender.direction == .right {
            Show_Menu()
        }
    }
    
    @IBAction func Menu_Action(_ sender: Any) {
        if AppDelegate.Manu_Bool {
            Show_Menu()
        }
        else {
            Hide_Menu()
        }
    }
    
    
    func Show_Menu() {
        
        UIView.animate(withDuration: 0.4) { ()->Void in
            
            self.navigationController?.navigationBar.isHidden = true
            self.Menu_VC.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width-130, height: UIScreen.main.bounds.size.height)
            self.addChildViewController(self.Menu_VC)
            self.view.addSubview(self.Menu_VC.view)
            AppDelegate.Manu_Bool = false
        }
    }
    func Hide_Menu()  {
        
        UIView.animate(withDuration: 0.3, animations: { ()->Void in
            
            self.navigationController?.navigationBar.isHidden = false
            self.Menu_VC.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width:  UIScreen.main.bounds.size.width-100, height:  UIScreen.main.bounds.size.height)
        }) { (finished) in
            
            self.Menu_VC.view.removeFromSuperview()
        }
        AppDelegate.Manu_Bool = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }


}

