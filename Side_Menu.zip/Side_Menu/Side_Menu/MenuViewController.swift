import UIKit

class MenuViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var title_arr : [String] = ["Society Rules","Rent a House","House On Rent","Gallery","Logout"]
    var img_arr = [#imageLiteral(resourceName: "icons8-rules-32"),#imageLiteral(resourceName: "icons8-rent-32"),#imageLiteral(resourceName: "icons8-house-32"),#imageLiteral(resourceName: "icons8-photo-gallery-32"),#imageLiteral(resourceName: "icons8-logout-rounded-down-32")]
   // var cell_color = [#colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1),#colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1),#colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1),#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1),#colorLiteral(red: 0.9568627477, green: 0.6588235497, blue: 0.5450980663, alpha: 1)]
    
    @IBOutlet weak var profileDetailView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        //profileDetailView.rowHeight = 200
        //profileDetailView.estimatedRowHeight = UITableViewAutomaticDimension
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        Hide_Menu()
    }
    func Hide_Menu()  {
        UIView.animate(withDuration: 0.3, animations: { ()->Void in
            self.navigationController?.navigationBar.isHidden = false
            self.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width:  UIScreen.main.bounds.size.width, height:  UIScreen.main.bounds.size.height)
        }) { (finished) in
            
            self.view.removeFromSuperview()
        }
        AppDelegate.Manu_Bool = true
    }
    override func viewWillAppear(_ animated: Bool) {
        profileDetailView.delegate = self
        profileDetailView.dataSource = self
        profileDetailView.reloadData()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }else{
            return 4
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProfileTableViewCell", for: indexPath) as! ProfileTableViewCell
            cell.profileImage.clipsToBounds = true
            cell.profileImage.layer.cornerRadius =  10//cell.profileImage.frame.size.height/2//67
            cell.profileImage.layer.borderWidth = 2.0
            cell.profileImage.layer.borderColor = UIColor.purple.cgColor
            cell.profileImage.image = UIImage(named: "man.png")
            cell.emailLabel.text = "vikas patil"
            cell.profileImage.sizeToFit()
            cell.emailLabel.sizeToFit()
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MenuTableViewCell
            cell.label_title.text = title_arr[indexPath.row]
           // cell.backgroundColor = cell_color[indexPath.row]
            cell.menu_img.image = img_arr[indexPath.row]
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 1 {
            print(title_arr[indexPath.row])
        }
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.0
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.0
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 100
        }else{
            return 68.0
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }
}
