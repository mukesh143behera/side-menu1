import UIKit

class MenuTableViewCell: UITableViewCell {

    @IBOutlet weak var label_title: UILabel!
    @IBOutlet weak var menu_img: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()

    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
