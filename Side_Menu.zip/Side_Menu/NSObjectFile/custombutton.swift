//
//  custombutton.swift
//  secreteryview1
//
//  Created by 851 on 27/06/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class custombutton: NSObject {
 
    
    func createbtn (frm:CGRect,img:UIImage) -> RoundButton {
        let btn = RoundButton(type: .custom)
        btn.frame = frm
        btn.layer.cornerRadius = 30
        btn.layer.borderWidth = 1
        btn.backgroundColor = #colorLiteral(red: 0.7950199875, green: 0.3394970114, blue: 1, alpha: 1)
       // let img = UIImage(named: "notice.png")
        btn.setImage(img, for: .normal)
        return btn
    }
}
