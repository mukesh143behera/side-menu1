//
//  MenuBarButtonName.swift
//  secreteryview1
//
//  Created by 1 on 12/07/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class MenuBarButtonName: NSObject {

    func createname(frm:CGRect,name:String) -> UILabel {
        let lbl = UILabel()
        lbl.frame = frm
        lbl.text = name
        lbl.tintColor = UIColor.black
        lbl.textAlignment = .left
        return lbl
    }
}
