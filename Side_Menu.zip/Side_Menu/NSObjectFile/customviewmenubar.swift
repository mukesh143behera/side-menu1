//
//  customviewmenubar.swift
//  secreteryview1
//
//  Created by 1 on 12/07/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class customviewmenubar: NSObject {

    func createview(frm:CGRect) ->UIView
    {
        let view1 = UIView()
        view1.frame = frm
        //view1.backgroundColor = #colorLiteral(red: 0.7537701726, green: 0.2315050066, blue: 0.9464060664, alpha: 1)
        view1.backgroundColor = .clear
        return view1
    }
}
